<?php
session_start();
include("header.html");
if(isset($_SESSION['$Name']));
{
    $name =  $_SESSION['$Name'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="css/home.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <div id = HeroPIC> <img id= "HeroPic" src="Images/HeroPic.jpg" alt="An image of mountains"></div>
</head>
<body>
    <main> 

        <div id = "leftBar">
            <img id= "profilePic" src="Images/profilePic.jpg" alt="An image of Hunter Dietzebach">
            <h1>My Skills</h1> 
    <p>HTML</p> 
    <div class="container"> 
        <div class="skill html">90%</div> 
    </div> 
  
    <p>PHP</p> 
    <div class="container"> 
        <div class="skill php">60%</div> 
    </div> 

    <p>Python</p> 
    <div class="container"> 
        <div class="skill Python">80%</div> 
    </div> 

    <p>Java</p> 
    <div class="container"> 
        <div class="skill Java">95%</div> 
    </div> 

    <p>English</p> 
    <div class="container"> 
        <div class="skill English">100%</div> 
    </div> 

    <p>Spanish</p> 
    <div class="container"> 
        <div class="skill Spanish">60%</div> 
    </div> 

    <p>Enthusiasm</p> 
    <div class="container"> 
        <div class="skill Enthusiasm">110%</div> 
    </div> 


    
        </div>
        
        <div id = rightBar>
            
                <p>Welcome to my Web Resume <?php echo $name;?>, <br>
                &nbsp;&nbsp;&nbsp;&nbsp;My name is Hunter Dietzenbach. I am currently a Student at Montana State Univeristy. GO CATS! I built this website as a practice and a demonstration of my HTML, CSS, and PHP skills.
                Currently, it is a W.I.P. I started development at the end of July 2024 and will continue updating it over time.
                whether you are a potential employer a friend of mine or just looking around I hope you enjoy what you see. <br> 
                <br>
                </p>

                <h2>-----Change Log-----</h2>
                <ul>
                    <li>  Update 1: Added a Projects tab and improved Usability Heuristics as well as slightly altered color scheme. 11/21/24 </li>
                    <br>
                     <li>  Update 2: Added another Project as well as small QOL improvments. 4/11/25 </li>
                    <br>
                     <li> Update 3: Added an email notfication and updated home page 9/23/2025 </li>
                </ul>
              
                <br>
                <p>Thank you for taking a look. Please</p>
                <a id="signin" href="index.php"> sign in.</a>
                
            
        </div>

    </main>
    
</body>
</html>

<?php
include("footer.html")
?>