<?php
session_start();
include("header.html");
if(isset($_SESSION['$Name']));
{
    $name =  $_SESSION['$Name'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="home.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <div id = heroPIC></div>
</head>
<body>
    <main> 

        <div id = "leftBar">
            <img id= "profilePic" src="Images/profilePic.jpg" alt="An image of Hunter Dietzebach">
            <h1>My Skills</h1> 
    <p>HTML</p> 
    <div class="container"> 
        <div class="skill html">90%</div> 
    </div> 
  
    <p>PHP</p> 
    <div class="container"> 
        <div class="skill php">60%</div> 
    </div> 

    <p>Python</p> 
    <div class="container"> 
        <div class="skill Python">80%</div> 
    </div> 

    <p>Java</p> 
    <div class="container"> 
        <div class="skill Java">95%</div> 
    </div> 

    <p>English</p> 
    <div class="container"> 
        <div class="skill English">100%</div> 
    </div> 

    <p>Spanish</p> 
    <div class="container"> 
        <div class="skill Spanish">60%</div> 
    </div> 

    <p>Enthusiasm</p> 
    <div class="container"> 
        <div class="skill Enthusiasm">110%</div> 
    </div> 


    
        </div>
        
        <div id = rightBar>

            <div id="Hello">  
                <p>Welcome to my web resume <?php echo $name; ?>, <br>
                I built this WebSite as Pratice and a deomonstration of my html, css, and php skills. 
                curently it is a W.I.P I started development at the end of July 2024 and will continue updating it over time <br>
                <br>Thank you for taking a look.
                <a href="index.php"> sign in</a>
                </p>
            </div>
        </div>

    </main>
    
</body>
</html>

<?php
include("footer.html")
?>