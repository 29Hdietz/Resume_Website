<?php
include("header.html");
?>

<!DOCTYPE html>
<link rel="stylesheet" href="resume.css">s
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
        
</head>
<body>
    <main> 
    <object class="pdf" 
            data="Images/HDResume.pdf"
            width="800"
            height="500">
    </object>
    </main>
   
</body>
</html>

<?php
include("footer.html")
?>